# MotionForge 0.1 — Android motion-graphics prototype

This is a real native Android Java project (not a web wrapper). It demonstrates:
- A rendered preview canvas
- Multiple shape/text layers
- A 6-second timeline with a draggable playhead
- Per-layer transform keyframes (position, scale, rotation, opacity)
- Linear, smooth, ease-in, and ease-out interpolation
- Cloud APK builds with GitHub Actions

## Build in the cloud from a phone/tablet

1. Create a new empty GitHub repository named `MotionForge`.
2. Upload this file as `MotionForge-source.zip` to the repository root.
3. Create `.github/workflows/android.yml` in GitHub and paste the workflow from the separately supplied `android-workflow.yml`.
4. Open the repository's **Actions** tab and run **Build MotionForge APK**.
5. Open the completed run and download the `MotionForge-debug-apk` artifact. Extract it and install `app-debug.apk`.

## Current scope

This is a foundation build, not a full After Effects replacement yet. It intentionally has no export pipeline or advanced effect stack in v0.1. Next milestones should add editable transform values, layer management, cubic Bezier graph editing, image/video import, and a MediaCodec-based MP4 export pipeline.

## Technical notes

- Java 17
- Android Gradle Plugin 8.7.3
- compileSdk 35 / minSdk 23
- No third-party runtime dependencies
