package com.motionforge.app;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {
    private EditorView editor;
    private TextView status;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(15, 17, 24));
        getWindow().setNavigationBarColor(Color.rgb(15, 17, 24));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(15, 17, 24));

        TextView title = new TextView(this);
        title.setText("MOTIONFORGE  •  0.1");
        title.setTextColor(Color.WHITE);
        title.setTextSize(18);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setPadding(dp(16), dp(15), dp(16), dp(12));
        root.addView(title);

        status = new TextView(this);
        status.setText("Motion graphics lab  •  30 FPS timeline");
        status.setTextColor(Color.rgb(170, 180, 200));
        status.setTextSize(12);
        status.setPadding(dp(16), 0, dp(16), dp(8));
        root.addView(status);

        editor = new EditorView(this);
        LinearLayout.LayoutParams editorParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f);
        editorParams.setMargins(dp(10), 0, dp(10), 0);
        root.addView(editor, editorParams);

        TextView timelineLabel = new TextView(this);
        timelineLabel.setText("TIMELINE  •  Tap anywhere on the ruler to scrub");
        timelineLabel.setTextColor(Color.rgb(200, 210, 230));
        timelineLabel.setTextSize(12);
        timelineLabel.setPadding(dp(16), dp(10), dp(16), dp(6));
        root.addView(timelineLabel);

        HorizontalScrollView toolsScroll = new HorizontalScrollView(this);
        toolsScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout tools = new LinearLayout(this);
        tools.setOrientation(LinearLayout.HORIZONTAL);
        tools.setPadding(dp(8), dp(4), dp(8), dp(4));

        addButton(tools, "＋ Shape", v -> { editor.addLayer(false); updateStatus("Shape layer added"); });
        addButton(tools, "＋ Text", v -> { editor.addLayer(true); updateStatus("Text layer added"); });
        addButton(tools, "◆ Keyframe", v -> { editor.addKeyframe(); updateStatus("Keyframe saved at " + editor.getTimeLabel()); });
        addButton(tools, "▶ / Pause", v -> { editor.togglePlayback(); updateStatus(editor.isPlaying() ? "Playing preview" : "Preview paused"); });
        addButton(tools, "Easing", v -> { editor.cycleEasing(); updateStatus("Interpolation: " + editor.getEasingName()); });
        addButton(tools, "Reset", v -> { editor.resetAnimation(); updateStatus("Animation reset"); });

        toolsScroll.addView(tools);
        root.addView(toolsScroll);

        TextView hint = new TextView(this);
        hint.setText("MVP: animated layers, keyframes, scrubbing & easing. Export and advanced effects are planned next.");
        hint.setTextColor(Color.rgb(145, 155, 175));
        hint.setTextSize(11);
        hint.setPadding(dp(16), dp(6), dp(16), dp(12));
        root.addView(hint);

        setContentView(root);
    }

    private void updateStatus(String text) { status.setText(text); }

    private void addButton(LinearLayout row, String label, View.OnClickListener click) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(12);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(48, 59, 83)));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, dp(48));
        p.setMargins(dp(4), 0, dp(4), 0);
        row.addView(b, p);
        b.setOnClickListener(click);
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
