package com.motionforge.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class EditorView extends View {
    private static final long DURATION_MS = 6000;
    private static final int FPS = 30;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final List<Layer> layers = new ArrayList<>();
    private long playheadMs = 0;
    private long lastFrameMs = 0;
    private boolean playing = false;
    private int easingMode = 1;
    private int selectedLayer = 0;
    private float density;
    private float previewBottom;
    private float timelineTop;
    private float rulerLeft;
    private float rulerRight;

    static class Transform {
        float x, y, scale, rotation, opacity;
        Transform(float x, float y, float scale, float rotation, float opacity) {
            this.x=x; this.y=y; this.scale=scale; this.rotation=rotation; this.opacity=opacity;
        }
        Transform copy() { return new Transform(x,y,scale,rotation,opacity); }
    }
    static class Keyframe {
        long time;
        Transform value;
        Keyframe(long t, Transform v) { time=t; value=v.copy(); }
    }
    static class Layer {
        String name;
        boolean text;
        int color;
        List<Keyframe> keys = new ArrayList<>();
        Layer(String n, boolean isText, int c) { name=n; text=isText; color=c; }
    }

    public EditorView(Context context) {
        super(context);
        density = getResources().getDisplayMetrics().density;
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        Layer first = new Layer("Shape 1", false, Color.rgb(85, 190, 255));
        first.keys.add(new Keyframe(0, new Transform(.22f,.45f,.72f,-12,1)));
        first.keys.add(new Keyframe(3000, new Transform(.78f,.42f,1.15f,18,1)));
        first.keys.add(new Keyframe(6000, new Transform(.50f,.62f,.85f,0,1)));
        layers.add(first);
        Layer second = new Layer("Title 1", true, Color.WHITE);
        second.keys.add(new Keyframe(0, new Transform(.50f,.77f,1f,0,0)));
        second.keys.add(new Keyframe(1200, new Transform(.50f,.77f,1f,0,1)));
        layers.add(second);
    }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        float w=getWidth(), h=getHeight();
        if (w<=0 || h<=0) return;
        c.drawColor(Color.rgb(20,23,32));

        // Preview canvas
        float pad=12*density;
        float previewTop=pad;
        previewBottom=Math.min(h*0.69f, w*0.82f);
        RectF preview = new RectF(pad, previewTop, w-pad, previewBottom);
        p.setColor(Color.rgb(8,10,16)); p.setStyle(Paint.Style.FILL);
        c.drawRoundRect(preview, 12*density, 12*density, p);
        c.save();
        c.clipRect(preview);
        p.setColor(Color.rgb(28,33,46)); p.setStrokeWidth(1*density); p.setStyle(Paint.Style.STROKE);
        for(int i=1;i<8;i++){
            float x=preview.left+preview.width()*i/8f;
            c.drawLine(x,preview.top,x,preview.bottom,p);
        }
        for(int i=1;i<6;i++){
            float y=preview.top+preview.height()*i/6f;
            c.drawLine(preview.left,y,preview.right,y,p);
        }
        p.setStyle(Paint.Style.FILL);
        for (int i=0;i<layers.size();i++) {
            Layer layer=layers.get(i);
            Transform t=evaluate(layer,playheadMs);
            float cx=preview.left+preview.width()*t.x;
            float cy=preview.top+preview.height()*t.y;
            c.save();
            c.translate(cx,cy);
            c.rotate(t.rotation);
            c.scale(t.scale,t.scale);
            p.setAlpha(Math.max(0,Math.min(255,(int)(255*t.opacity))));
            p.setColor(layer.color);
            if(layer.text){
                p.setTextAlign(Paint.Align.CENTER);
                p.setTextSize(28*density);
                p.setFakeBoldText(true);
                c.drawText("MOTION",0,0,p);
                p.setFakeBoldText(false);
            } else {
                RectF r=new RectF(-42*density,-42*density,42*density,42*density);
                c.drawRoundRect(r,14*density,14*density,p);
                p.setColor(Color.argb((int)(110*t.opacity),255,255,255));
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2*density);
                c.drawRoundRect(r,14*density,14*density,p); p.setStyle(Paint.Style.FILL);
            }
            p.setAlpha(255);
            c.restore();
        }
        c.restore();

        p.setStyle(Paint.Style.FILL);
        p.setColor(Color.WHITE); p.setTextSize(11*density); p.setTextAlign(Paint.Align.LEFT);
        c.drawText("PREVIEW  •  "+String.format(Locale.US,"%.2f s",playheadMs/1000f),pad,previewBottom+18*density,p);

        timelineTop=previewBottom+34*density;
        rulerLeft=pad;
        rulerRight=w-pad;
        // Timeline panel
        p.setColor(Color.rgb(28,32,44));
        c.drawRoundRect(new RectF(pad,timelineTop,w-pad,h-pad),10*density,10*density,p);
        float trackStart=timelineTop+26*density;
        float trackH=27*density;
        p.setTextSize(10*density);
        for(int s=0;s<=6;s++){
            float x=rulerLeft+(rulerRight-rulerLeft)*s/6f;
            p.setColor(Color.rgb(125,137,158));
            c.drawLine(x,timelineTop+5*density,x,h-pad,p);
            p.setColor(Color.rgb(205,214,230));
            c.drawText(s+"s",x+3*density,timelineTop+17*density,p);
        }
        for(int i=0;i<layers.size();i++){
            Layer layer=layers.get(i);
            float y=trackStart+i*trackH;
            p.setColor(i==selectedLayer?Color.rgb(51,70,103):Color.rgb(39,44,58));
            c.drawRoundRect(new RectF(rulerLeft+2*density,y,rulerRight-2*density,y+trackH-3*density),4*density,4*density,p);
            p.setColor(layer.color);
            p.setTextSize(9*density);
            c.drawText(layer.name, rulerLeft+7*density, y+trackH/2+3*density,p);
            for(Keyframe k:layer.keys){
                float kx=rulerLeft+(rulerRight-rulerLeft)*(k.time/(float)DURATION_MS);
                p.setColor(Color.rgb(255,199,87));
                Path diamond=new Path();
                diamond.moveTo(kx,y+4*density); diamond.lineTo(kx+5*density,y+trackH/2-1*density);
                diamond.lineTo(kx,y+trackH-5*density); diamond.lineTo(kx-5*density,y+trackH/2-1*density); diamond.close();
                c.drawPath(diamond,p);
            }
        }
        float px=rulerLeft+(rulerRight-rulerLeft)*(playheadMs/(float)DURATION_MS);
        p.setColor(Color.rgb(255,90,110)); p.setStrokeWidth(2*density);
        c.drawLine(px,timelineTop,h-pad,p);
        p.setStyle(Paint.Style.FILL);
        p.setColor(Color.rgb(255,90,110));
        Path head=new Path(); head.moveTo(px-6*density,timelineTop); head.lineTo(px+6*density,timelineTop); head.lineTo(px,timelineTop+8*density); head.close(); c.drawPath(head,p);

        if(playing){
            long now=SystemClock.uptimeMillis();
            if(lastFrameMs==0) lastFrameMs=now;
            long delta=Math.min(100,now-lastFrameMs);
            playheadMs+=delta;
            if(playheadMs>DURATION_MS){playheadMs=0;}
            lastFrameMs=now;
            postInvalidateDelayed(1000/FPS);
        }
    }

    private Transform evaluate(Layer layer,long time){
        if(layer.keys.isEmpty()) return new Transform(.5f,.5f,1,0,1);
        List<Keyframe> keys=layer.keys;
        if(time<=keys.get(0).time) return keys.get(0).value.copy();
        if(time>=keys.get(keys.size()-1).time) return keys.get(keys.size()-1).value.copy();
        Keyframe a=keys.get(0), b=keys.get(keys.size()-1);
        for(int i=0;i<keys.size()-1;i++){
            if(time>=keys.get(i).time && time<=keys.get(i+1).time){a=keys.get(i);b=keys.get(i+1);break;}
        }
        float t=(time-a.time)/(float)Math.max(1,b.time-a.time);
        if(easingMode==1) t=t*t*(3-2*t);
        else if(easingMode==2) t=t*t;
        else if(easingMode==3) t=1-(1-t)*(1-t);
        Transform x=a.value,y=b.value;
        return new Transform(lerp(x.x,y.x,t),lerp(x.y,y.y,t),lerp(x.scale,y.scale,t),
                lerp(x.rotation,y.rotation,t),lerp(x.opacity,y.opacity,t));
    }
    private float lerp(float a,float b,float t){return a+(b-a)*t;}

    public void addLayer(boolean text){
        int color=text?Color.WHITE:new int[]{Color.rgb(255,110,135),Color.rgb(126,235,170),Color.rgb(255,194,92)}[layers.size()%3];
        Layer l=new Layer((text?"Text ":"Shape ")+(layers.size()+1),text,color);
        l.keys.add(new Keyframe(0,new Transform(.5f,.5f,1,0,0)));
        l.keys.add(new Keyframe(DURATION_MS,new Transform(.5f,.5f,1,0,1)));
        layers.add(l); selectedLayer=layers.size()-1; invalidate();
    }
    public void addKeyframe(){
        if(layers.isEmpty()) return;
        Layer l=layers.get(selectedLayer);
        Transform value=evaluate(l,playheadMs);
        // Give each newly added keyframe a visible motion offset, useful for testing the engine.
        if(!l.keys.isEmpty()){
            Keyframe last=l.keys.get(l.keys.size()-1);
            if(playheadMs>last.time){value.x=Math.max(.08f,Math.min(.92f,value.x+.12f));value.rotation+=10;}
        }
        int at=0;
        while(at<l.keys.size() && l.keys.get(at).time<playheadMs) at++;
        if(at<l.keys.size() && l.keys.get(at).time==playheadMs) l.keys.set(at,new Keyframe(playheadMs,value));
        else l.keys.add(at,new Keyframe(playheadMs,value));
        invalidate();
    }
    public void togglePlayback(){playing=!playing;lastFrameMs=0;invalidate();}
    public boolean isPlaying(){return playing;}
    public void cycleEasing(){easingMode=(easingMode+1)%4;invalidate();}
    public String getEasingName(){return new String[]{"Linear","Smooth","Ease In","Ease Out"}[easingMode];}
    public String getTimeLabel(){return String.format(Locale.US,"%.2f s",playheadMs/1000f);}
    public void resetAnimation(){playing=false;playheadMs=0;lastFrameMs=0;invalidate();}

    @Override public boolean onTouchEvent(MotionEvent e){
        if(e.getAction()==MotionEvent.ACTION_DOWN || e.getAction()==MotionEvent.ACTION_MOVE){
            float y=e.getY();
            if(y>=timelineTop && y<getHeight()-8*density){
                float f=(e.getX()-rulerLeft)/Math.max(1,(rulerRight-rulerLeft));
                playheadMs=(long)(Math.max(0,Math.min(1,f))*DURATION_MS);
                // Tap a track row to select it.
                float trackStart=timelineTop+26*density;
                int row=(int)((y-trackStart)/(27*density));
                if(row>=0 && row<layers.size()) selectedLayer=row;
                invalidate(); return true;
            }
        }
        return true;
    }
}
